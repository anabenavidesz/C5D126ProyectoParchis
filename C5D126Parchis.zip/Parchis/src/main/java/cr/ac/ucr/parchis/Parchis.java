package cr.ac.ucr.parchis;
import cr.ac.ucr.parchis.controller.ParchisController;

//Clase principal
public class Parchis {

    public static void main(String[] args) {
       
       new ParchisController();
    }
}
